'''
Function:
    致远OA 任意文件上传
Author:
    spmonkey，夜梓月
Email：
    spmonkey@hscsec.cn
Blog:
    https://spmonkey.github.io/
GitHub:
    https://github.com/spmonkey/
'''
# -*- coding: utf-8 -*-

'''https://www.cnblogs.com/bonelee/p/15160660.html'''