'''
Function:
    yonyouchangjie_sqli3
Author:
    spmonkey，夜梓月
Email：
    spmonkey@hscsec.cn
Blog:
    https://spmonkey.github.io/
GitHub:
    https://github.com/spmonkey/
'''
# -*- coding: utf-8 -*-

"""WebSer~1/create_site.php?site_id=1"""